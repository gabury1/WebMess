package com.example.WebMess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebMessApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebMessApplication.class, args);
	}

}
