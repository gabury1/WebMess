package com.example.WebMess;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebMessApplicationTests {

	@Test
	void contextLoads() {
	}

}
